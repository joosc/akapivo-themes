<?php

/**
 * @file
 * Bartik's theme implementation to display a node.
 *
 * Available variables:
 * - $title: the (sanitized) title of the node.
 * - $content: An array of node items. Use render($content) to print them all,
 *   or print a subset such as render($content['field_example']). Use
 *   hide($content['field_example']) to temporarily suppress the printing of a
 *   given element.
 * - $user_picture: The node author's picture from user-picture.tpl.php.
 * - $date: Formatted creation date. Preprocess functions can reformat it by
 *   calling format_date() with the desired parameters on the $created variable.
 * - $name: Themed username of node author output from theme_username().
 * - $node_url: Direct URL of the current node.
 * - $display_submitted: Whether submission information should be displayed.
 * - $submitted: Submission information created from $name and $date during
 *   template_preprocess_node().
 * - $classes: String of classes that can be used to style contextually through
 *   CSS. It can be manipulated through the variable $classes_array from
 *   preprocess functions. The default values can be one or more of the
 *   following:
 *   - node: The current template type; for example, "theming hook".
 *   - node-[type]: The current node type. For example, if the node is a
 *     "Blog entry" it would result in "node-blog". Note that the machine
 *     name will often be in a short form of the human readable label.
 *   - node-teaser: Nodes in teaser form.
 *   - node-preview: Nodes in preview mode.
 *   The following are controlled through the node publishing options.
 *   - node-promoted: Nodes promoted to the front page.
 *   - node-sticky: Nodes ordered above other non-sticky nodes in teaser
 *     listings.
 *   - node-unpublished: Unpublished nodes visible only to administrators.
 * - $title_prefix (array): An array containing additional output populated by
 *   modules, intended to be displayed in front of the main title tag that
 *   appears in the template.
 * - $title_suffix (array): An array containing additional output populated by
 *   modules, intended to be displayed after the main title tag that appears in
 *   the template.
 *
 * Other variables:
 * - $node: Full node object. Contains data that may not be safe.
 * - $type: Node type; for example, story, page, blog, etc.
 * - $comment_count: Number of comments attached to the node.
 * - $uid: User ID of the node author.
 * - $created: Time the node was published formatted in Unix timestamp.
 * - $classes_array: Array of html class attribute values. It is flattened
 *   into a string within the variable $classes.
 * - $zebra: Outputs either "even" or "odd". Useful for zebra striping in
 *   teaser listings.
 * - $id: Position of the node. Increments each time it's output.
 *
 * Node status variables:
 * - $view_mode: View mode; for example, "full", "teaser".
 * - $teaser: Flag for the teaser state (shortcut for $view_mode == 'teaser').
 * - $page: Flag for the full page state.
 * - $promote: Flag for front page promotion state.
 * - $sticky: Flags for sticky post setting.
 * - $status: Flag for published status.
 * - $comment: State of comment settings for the node.
 * - $readmore: Flags true if the teaser content of the node cannot hold the
 *   main body content.
 * - $is_front: Flags true when presented in the front page.
 * - $logged_in: Flags true when the current user is a logged-in member.
 * - $is_admin: Flags true when the current user is an administrator.
 *
 * Field variables: for each field instance attached to the node a corresponding
 * variable is defined; for example, $node->body becomes $body. When needing to
 * access a field's raw values, developers/themers are strongly encouraged to
 * use these variables. Otherwise they will have to explicitly specify the
 * desired field language; for example, $node->body['en'], thus overriding any
 * language negotiation rule that was previously applied.
 *
 * @see template_preprocess()
 * @see template_preprocess_node()
 * @see template_process()
 */
?>
<div id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?> clearfix"<?php print $attributes; ?>>

<?php if ($teaser){
	echo '<div class="well news-item">';
} else {
	echo '<div class="col-md-8 col-lg-6">';
} ?>

  <?php print render($title_prefix); ?>
  <?php if (!$page): ?>
    <h2<?php print $title_attributes; ?>>
      <a href="<?php print $node_url; ?>"><?php print $title; ?></a>
    </h2>
  <?php endif; ?>
  <?php print render($title_suffix); ?>

  <?php if ($display_submitted): ?>
    <div class="meta submitted">
      <?php print $user_picture; ?>
      <?php print $submitted; ?>
    </div>
  <?php endif; ?>

  <div class="content clearfix"<?php print $content_attributes; ?>>
    <?php
      // We hide the comments and links now so that we can render them later.
      hide($content['comments']);
      hide($content['links']);
      hide($content['field_nieuws_afbeelding']);
      hide($content['disqus']);
      
      // thumbnail bij teaser?
      if($teaser){
      	if(count($field_nieuws_afbeelding) > 0){
      		$thumb = image_style_url('square',$field_nieuws_afbeelding[0]['uri']);
      		hide($content['field_nieuws_afbeelding']);
      		echo l('<img class="img-thumbnail pull-right" src="'.$thumb.'"></img>','node/'.$node->nid, array('html'=>TRUE));
      	}
      } else {
	      hide($content['field_links_to_website']);
      }
      
      print render($content);
      print '<br/><br/>';
      
      /*
      if(!$teaser){
			
			if(count($field_links_to_website) > 0){
      		
      			foreach($field_links_to_website as $related_project){
      		
	      			$prog_nid = $related_project['nid'];
	      			$prog_node = node_load($prog_nid);
	      			$view = node_view($prog_node, 'teaser');
					$rendered = drupal_render($view);
				
					print $rendered;
				}
	    	}      
      
      }
      */
      
      
      
    ?>
  </div>

  <?php
    // Remove the "Add new comment" link on the teaser page or if the comment
    // form is being displayed on the same page.
    if ($teaser || !empty($content['comments']['comment_form'])) {
      unset($content['links']['comment']['#links']['comment-add']);
    }
    // Only display the wrapper div if there are links.
    $links = render($content['links']);
    if ($links):
  ?>
    <div class="link-wrapper">
      <?php 
      		
      		if($teaser){
      			$btn_readmore = l('<button class="btn-md">Lees verder</button>','node/'.$node->nid,
	    					array('html'=>TRUE));
      			$btn_programma = '<br/><br/>';
      			
      			if(count($field_links_to_website) > 0){
      				
      				for($i=0; $i<count($field_links_to_website['und']); $i++){
	      				$prog_nid = $field_links_to_website['und'][$i]['nid'];
	      				$prog_node = node_load($prog_nid);
	      				
	      				$btn_programma .= l('<button class="btn-block">'.
	    					'<span class="minithumb">'.
	    					'<img src="'.
	    					image_style_url('minisquare',$prog_node->field_header_afbeelding['und'][0]['uri']).
	    					'"></img></span>&nbsp;&nbsp;'.
	    									$prog_node->title.'</button>',
	    					'node/'.$prog_nid,
	    					array('html'=>TRUE));
	      									
	      									
	      			}
      			}
      			
      			echo $btn_readmore.$btn_programma;
      		} else {
	      		
	      		 print $links;
	      	}
      	?>
    </div>
  <?php endif; ?>

  <?php print render($content['comments']); ?>
  
  </div>
  
  <?php
  if(!$teaser && count($field_nieuws_afbeelding) > 0){
		echo '<div class="col-md-4 col-lg-6">';
			print '<img class="img-responsive" src="'.image_style_url('largest',$field_nieuws_afbeelding[0]['uri']).'"></img>';
		echo '</div>';
	} if (!$teaser){
		
		echo '<div class="clearfix"></div><div class="col-md-8 col-lg-6"><div class="row disqus-row">';
			echo '<h3 class="disqus-title">Reageer:</h3>';
			print render($content['disqus']);
		echo '</div>';
		
		if(count($field_links_to_website) > 0){
				
				echo '<h3>Meer weten?</h3>';
				
      			foreach($field_links_to_website as $related_project){
      			  echo '<div class="row">';
	      				$prog_nid = $related_project['nid'];
	      				$prog_node = node_load($prog_nid);
	      				$view = node_view($prog_node, 'teaser');
						$rendered = drupal_render($view);
						print $rendered;
					echo '</div>';
				}
	    	}
	    
	    echo '</div>';     	
	
	}
	
	
	
	
	
	?>
  
  

</div>
